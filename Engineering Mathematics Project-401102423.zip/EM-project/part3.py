import numpy as np
import matplotlib.pyplot as plt
import scipy.io
# Read the raw MRI data and perform zero-filling
raw_data = scipy.io.loadmat('rawkneedata.mat')['dat']  # Replace 'raw_mri_data.dat' with your raw data file
print(raw_data)
zero_filled_data = np.zeros((256, 256), dtype=complex)
zero_filled_data[:raw_data.shape[0], :raw_data.shape[1]] = raw_data

# Perform inverse Fourier transform
reconstructed_image = np.fft.ifft2(zero_filled_data)
# Perform FFT shift
shifted_image = np.fft.fftshift(reconstructed_image)

# Display and save the shifted image
plt.imshow(np.abs(shifted_image), cmap='gray')
plt.axis('off')
plt.imsave('shifted_image.png', np.abs(shifted_image), cmap='gray') 
plt.show()
