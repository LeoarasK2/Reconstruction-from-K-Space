import cv2
import matplotlib.pyplot as plt
import numpy as np
# Load the image using OpenCV
image = cv2.imread('shifted_image.png', cv2.IMREAD_GRAYSCALE)

# Calculate the histogram
histogram, bin_edges = np.histogram(image.flatten(), bins=256, range=[0, 256])

# Plot the histogram
plt.plot(histogram, color='black')
plt.xlabel('Pixel Value')
plt.ylabel('Frequency')
plt.title('Image Histogram')
plt.show()

