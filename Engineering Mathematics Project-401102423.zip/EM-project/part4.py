import cv2
import numpy as np

import matplotlib.pyplot as plt

# Read the grayscale image
image = cv2.imread('kneeMRI.jpg', cv2.IMREAD_GRAYSCALE)
imageM = cv2.imread('shifted_image.png', cv2.IMREAD_GRAYSCALE)


def get_snr(I, K):
    # Calculate the SNR
    signal_power = np.mean(I) ** 2
    noise_power = np.mean((I - K) ** 2)
    snr = 10 * np.log10(signal_power / noise_power)
    return snr


def get_psnr(I, K):
    max_pixel_value = np.max(I)
    mse = np.mean((I - K) ** 2)
    psnr = 10 * np.log10((max_pixel_value ** 2) / mse)
    return psnr


# Add noise to the image (optional)
image2 = cv2.fastNlMeansDenoising(imageM, None, h=1, templateWindowSize=5, searchWindowSize=21)
# ...
plt.imsave('NLM.png', np.abs(image2), cmap='gray')
snr = get_snr(image2, image)

# Calculate the PSNR
psnr = get_psnr(image2, image)

print("nlm")
# Print the SNR and PSNR values
print("SNR: {:.2f} dB".format(snr))
print("PSNR: {:.2f} dB".format(psnr))
print("#########################")
####################################################

# Apply Gaussian blur
ksize = (3, 3)  # Adjust the kernel size as needed
sigmaX = 1  # Adjust the standard deviation as needed
gimage = cv2.GaussianBlur(imageM, ksize, sigmaX)
plt.imsave('Gaussian.png', np.abs(gimage), cmap='gray')
snr = get_snr(gimage, image)

# Calculate the PSNR
psnr = get_psnr(gimage, image)

print("gassian")
# Print the SNR and PSNR values
print("SNR: {:.2f} dB".format(snr))
print("PSNR: {:.2f} dB".format(psnr))
print("#########################")
# Apply mean
# ksize = (3, 3)  # Adjust the kernel size as needed
# mimage = cv2.blur(image, ksize)
ksize = 3  # Adjust the kernel size as needed
padded_image = cv2.copyMakeBorder(imageM, ksize // 2, ksize // 2, ksize // 2, ksize // 2, cv2.BORDER_REPLICATE)
mimage = np.zeros_like(imageM)

for i in range(ksize // 2, imageM.shape[0] + ksize // 2):
    for j in range(ksize // 2, imageM.shape[1] + ksize // 2):
        neighborhood = padded_image[i - ksize // 2:i + ksize // 2 + 1, j - ksize // 2:j + ksize // 2 + 1]
        mean_value = np.mean(neighborhood)
        mimage[i - ksize // 2, j - ksize // 2] = mean_value
plt.imsave('Mean.png', np.abs(mimage), cmap='gray')
snr = get_snr(mimage, image)

# Calculate the PSNR
psnr = get_psnr(mimage, image)

print("mean")
# Print the SNR and PSNR values
print("SNR: {:.2f} dB".format(snr))
print("PSNR: {:.2f} dB".format(psnr))
print("#########################")
# Apply median
# ksize = 5  # Adjust the kernel size as needed
# meimage = cv2.medianBlur(image, ksize)

ksize = 5  # Adjust the kernel size as needed
padded_image = cv2.copyMakeBorder(imageM, ksize // 2, ksize // 2, ksize // 2, ksize // 2, cv2.BORDER_REPLICATE)
meimage = np.zeros_like(imageM)

for i in range(ksize // 2, imageM.shape[0] + ksize // 2):
    for j in range(ksize // 2, imageM.shape[1] + ksize // 2):
        neighborhood = padded_image[i - ksize // 2:i + ksize // 2 + 1, j - ksize // 2:j + ksize // 2 + 1]
        median_value = np.median(neighborhood)
        meimage[i - ksize // 2, j - ksize // 2] = median_value
plt.imsave('Median.png', np.abs(meimage), cmap='gray')
snr = get_snr(meimage, image)

# Calculate the PSNR
psnr = get_psnr(meimage, image)

print("median")
# Print the SNR and PSNR values
print("SNR: {:.2f} dB".format(snr))
print("PSNR: {:.2f} dB".format(psnr))

print("#########################")
snr = get_snr(imageM, image)

# Calculate the PSNR
psnr = get_psnr(imageM, image)

print("original")
# Print the SNR and PSNR values
print("SNR: {:.2f} dB".format(snr))
print("PSNR: {:.2f} dB".format(psnr))
